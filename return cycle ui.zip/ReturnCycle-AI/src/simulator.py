"""Counterfactual simulator: change any assumption and recompute every pathway."""
from __future__ import annotations

import pandas as pd

from src.next_life_engine import analyze_product
from src.utils import PATHWAYS, PATHWAY_LABELS

SCENARIOS = {
    "A": ("Repair cost −20%", lambda b: {"repair_cost": b["repair_cost"] * 0.8}),
    "B": ("Resale market value +10%", lambda b: {"resale_value": b["resale_value"] * 1.10,
                                                 "refurbished_value": b["refurbished_value"] * 1.10}),
    "C": ("Reverse logistics cost −15%", lambda b: {"logistics_cost": b["logistics_cost"] * 0.85}),
    "D": ("Component recovery value +25%", lambda b: {"component_value": b["component_value"] * 1.25}),
    "E": ("Faster warehouse processing (−50% queue days)", lambda b: {"processing_days": b["processing_days"] * 0.5}),
}


def baseline(record: dict) -> dict:
    return analyze_product(record)


def compare(record: dict, overrides: dict, weights: dict | None = None) -> dict:
    """Run baseline vs counterfactual. Everything is recalculated by the real engine."""
    cur = analyze_product(record, weights=weights)
    new = analyze_product(record, overrides=overrides, weights=weights)
    cb, nb = cur["pathways"][cur["recommended"]], new["pathways"][new["recommended"]]
    rows = []
    for k in PATHWAYS:
        rows.append({"Pathway": PATHWAY_LABELS[k], "Current net": round(cur["pathways"][k]["net"]),
                     "Scenario net": round(new["pathways"][k]["net"]),
                     "Change": round(new["pathways"][k]["net"] - cur["pathways"][k]["net"])})
    return {
        "current": cur, "scenario": new, "table": pd.DataFrame(rows),
        "changed": cur["recommended"] != new["recommended"],
        "from_label": PATHWAY_LABELS[cur["recommended"]], "to_label": PATHWAY_LABELS[new["recommended"]],
        "delta_best_net": nb["net"] - cb["net"],
        "delta_keep_strategy": new["pathways"][cur["recommended"]]["net"] - cb["net"],
    }


def scenario_overrides(key: str, base_values: dict) -> dict:
    return SCENARIOS[key][1](base_values)


def run_all_scenarios(record: dict) -> pd.DataFrame:
    cur = analyze_product(record)
    cb = cur["pathways"][cur["recommended"]]["net"]
    rows = [{"Scenario": "Current", "Recommended": PATHWAY_LABELS[cur["recommended"]], "Best net recovery": round(cb),
             "Change vs current": 0, "Recommendation changed": False}]
    for key, (name, fn) in SCENARIOS.items():
        s = analyze_product(record, overrides=fn(cur["baseline_values"]))
        sb = s["pathways"][s["recommended"]]["net"]
        rows.append({"Scenario": f"{key} · {name}", "Recommended": PATHWAY_LABELS[s["recommended"]],
                     "Best net recovery": round(sb), "Change vs current": round(sb - cb),
                     "Recommendation changed": s["recommended"] != cur["recommended"]})
    return pd.DataFrame(rows)
