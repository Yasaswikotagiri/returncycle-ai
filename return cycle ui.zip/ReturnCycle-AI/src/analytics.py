"""Pre-aggregations and filters used by the dashboard / analytics pages (all on the dataframe)."""
from __future__ import annotations

import numpy as np
import pandas as pd

from src.utils import PATHWAY_LABELS, PATHWAYS

LOSS_LABELS = {"loss_depreciation": "Depreciation", "loss_damage": "Product damage & risk",
               "loss_accessories": "Missing accessories", "loss_logistics": "Reverse logistics",
               "loss_repair": "Repair cost", "loss_processing": "Processing cost"}


def apply_filters(df, date_range=None, categories=None, sellers=None, grades=None, reasons=None,
                  pathways=None, value_range=None, search=None, date_col="order_date"):
    m = pd.Series(True, index=df.index)
    if date_range and len(date_range) == 2 and date_range[0] and date_range[1]:
        d = pd.to_datetime(df[date_col])
        m &= (d >= pd.Timestamp(date_range[0])) & (d <= pd.Timestamp(date_range[1]))
    if categories:
        m &= df["category"].isin(categories)
    if sellers:
        m &= df["seller_type"].isin(sellers)
    if grades:
        m &= df["condition_grade"].isin(grades)
    if reasons:
        m &= df["return_reason"].isin(reasons)
    if pathways:
        m &= df["best_pathway"].isin(pathways)
    if value_range:
        m &= df["original_value"].between(value_range[0], value_range[1])
    if search:
        s = str(search).strip().lower()
        if s:
            hay = (df["return_id"].astype(str) + " " + df["product_id"].astype(str) + " " + df["category"].astype(str)
                   + " " + df.get("product_name", pd.Series("", index=df.index)).astype(str)).str.lower()
            m &= hay.str.contains(s, regex=False)
    return df[m]


def kpis(df: pd.DataFrame) -> dict:
    orig = df["original_value"].sum()
    actual = df["recovered_value"].sum()
    best = df["best_net_recovery"].sum()
    return {"returns": int(len(df)), "original_value": orig, "returned_value": df["market_value"].sum(),
            "recoverable_value": df["best_gross"].sum(), "net_recovered_optimized": best,
            "net_recovered_current": actual, "value_lost_current": orig - actual,
            "recovery_rate_current": actual / orig * 100 if orig else 0.0,
            "recovery_rate_optimized": best / orig * 100 if orig else 0.0,
            "uplift": best - actual}


def pathway_distribution(df, col="best_pathway") -> pd.DataFrame:
    counts = df[col].value_counts()
    out = pd.DataFrame({"Pathway": [PATHWAY_LABELS[k] for k in PATHWAYS]})
    out["Returns"] = out["Pathway"].map(counts).fillna(0).astype(int)
    return out


def funnel(df) -> pd.DataFrame:
    k = kpis(df)
    return pd.DataFrame({"Stage": ["Original product value", "Returned product value (market)",
                                   "Recoverable value (gross)", "Net recovered value"],
                         "Value": [k["original_value"], k["returned_value"], k["recoverable_value"],
                                   k["net_recovered_optimized"]]})


def loss_drivers(df) -> pd.DataFrame:
    out = pd.DataFrame({"Driver": list(LOSS_LABELS.values()),
                        "Value lost": [df[c].sum() for c in LOSS_LABELS]})
    return out.sort_values("Value lost", ascending=True)


def top_opportunities(df, n=15) -> pd.DataFrame:
    d = df.copy()
    d["uplift"] = d["best_net_recovery"] - d["recovered_value"]
    d = d.sort_values("uplift", ascending=False).head(n)
    return d


def monthly_trend(df, date_col="return_date") -> pd.DataFrame:
    d = df.copy()
    d["Month"] = pd.to_datetime(d[date_col]).dt.to_period("M").dt.to_timestamp()
    return d.groupby("Month").agg(Returns=("return_id", "count"), Original=("original_value", "sum"),
                                  Net=("best_net_recovery", "sum")).reset_index()


def return_rate_by(df, orders_summary, by="category", date_range=None, categories=None, sellers=None):
    if orders_summary is None or orders_summary.empty:
        return None
    o = orders_summary.copy()
    o["order_date"] = pd.to_datetime(o["order_date"])
    if date_range and len(date_range) == 2:
        o = o[(o["order_date"] >= pd.Timestamp(date_range[0])) & (o["order_date"] <= pd.Timestamp(date_range[1]))]
    if categories:
        o = o[o["category"].isin(categories)]
    if sellers:
        o = o[o["seller_type"].isin(sellers)]
    od = o.groupby(by)["orders"].sum()
    rd = df.groupby(by).size()
    out = pd.DataFrame({"Orders": od, "Returns": rd}).fillna(0)
    out = out[out["Orders"] > 0]
    out["Return rate %"] = out["Returns"] / out["Orders"] * 100
    return out.reset_index().rename(columns={by: by.replace("_", " ").title()})


def customer_patterns(df):
    g = df.groupby("customer_id").agg(Returns=("return_id", "count"), Value=("original_value", "sum"),
                                      Freq=("return_frequency", "max")).reset_index()
    dist = g["Returns"].clip(upper=6).value_counts().sort_index().rename_axis("Returns per customer").reset_index(name="Customers")
    dist["Returns per customer"] = dist["Returns per customer"].astype(str).replace({"6": "6+"})
    top = g.sort_values(["Returns", "Value"], ascending=False).head(10)
    return dist, top


def product_patterns(df, n=15) -> pd.DataFrame:
    g = df.groupby(["product_id", "category"]).agg(
        Product=("product_name", "first"), Returns=("return_id", "count"),
        Top_reason=("return_reason", lambda s: s.value_counts().index[0]),
        Avg_condition=("condition_score", "mean"), Net_recovery=("best_net_recovery", "sum")).reset_index()
    g["Avg_condition"] = g["Avg_condition"].round(1)
    g["Net_recovery"] = g["Net_recovery"].round(0)
    return g.sort_values("Returns", ascending=False).head(n)


def recovery_by_category(df) -> pd.DataFrame:
    g = df.groupby("category").agg(Original=("original_value", "sum"), Current=("recovered_value", "sum"),
                                   Optimized=("best_net_recovery", "sum"), Returns=("return_id", "count")).reset_index()
    g["Current rate %"] = g["Current"] / g["Original"] * 100
    g["Optimized rate %"] = g["Optimized"] / g["Original"] * 100
    return g.sort_values("Optimized rate %", ascending=False)


def net_by_pathway(df) -> pd.DataFrame:
    g = df.groupby("best_pathway").agg(Returns=("return_id", "count"), Net=("best_net_recovery", "sum"),
                                       Avg_net=("best_net_recovery", "mean")).reset_index()
    return g.rename(columns={"best_pathway": "Pathway"})


def loss_by(df, by) -> pd.DataFrame:
    d = df.copy()
    d["Loss (current practice)"] = d["original_value"] - d["recovered_value"]
    d["Loss (optimized)"] = d["original_value"] - d["best_net_recovery"]
    return d.groupby(by)[["Loss (current practice)", "Loss (optimized)"]].sum().reset_index().sort_values(
        "Loss (current practice)", ascending=False)


def circularity(df) -> pd.DataFrame:
    names = {"Resale": "Reused (resold)", "Refurbish": "Refurbished", "Component Recovery": "Components recovered",
             "Transformation": "Transformed", "Material Recovery": "Recycled (material)", "Disposal": "Disposed"}
    rows = []
    for lbl, nm in names.items():
        rows.append({"Outcome": nm, "Current practice": int((df["recovery_pathway"] == lbl).sum()),
                     "Optimized": int((df["best_pathway"] == lbl).sum())})
    out = pd.DataFrame(rows)
    out["Current %"] = out["Current practice"] / max(len(df), 1) * 100
    out["Optimized %"] = out["Optimized"] / max(len(df), 1) * 100
    return out


def circular_share(df) -> dict:
    n = max(len(df), 1)
    return {"current": (df["recovery_pathway"] != "Disposal").sum() / n * 100,
            "optimized": (df["best_pathway"] != "Disposal").sum() / n * 100}
